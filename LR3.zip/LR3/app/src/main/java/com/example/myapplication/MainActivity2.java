package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;

public class MainActivity2 extends AppCompatActivity {
    Ringtone ringtone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Uri notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        ringtone = RingtoneManager.getRingtone(this, notificationUri);
        if (ringtone == null) {
            notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            ringtone = RingtoneManager.getRingtone(this, notificationUri);
        }
        ringtone.play();
        //
    }


    public void OnClickCall21(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

        ringtone.stop();
    }

    public void OnClickCall22(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

        ringtone.stop();
    }


}