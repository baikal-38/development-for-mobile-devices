package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState!=null)
            count=savedInstanceState.getInt("count");




        setContentView(R.layout.activity_main);
        Button btnwd = (Button) findViewById(R.id.buttonWidth);
        TextView txtwd = (TextView) findViewById(R.id.textWidth);
        Button btnht = (Button) findViewById(R.id.buttonHeight);
        TextView txtht = (TextView) findViewById(R.id.textHeight);
        Button btnor = (Button) findViewById(R.id.buttonOrientation);
        TextView txtor = (TextView) findViewById(R.id.textOrientation);
        Button btncnt = (Button) findViewById(R.id.buttonCounter);
        TextView txtcnt = (TextView) findViewById(R.id.textCount);


        txtwd.setText("");
        txtht.setText("");
        txtor.setText("");
        txtcnt.setText(String.valueOf(count));

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        btnwd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                txtwd.setText(String.valueOf(metrics.widthPixels));
            } });

        btnht.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                txtht.setText(String.valueOf(metrics.heightPixels));
            } });

        btnor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
                {
                    txtor.setText("Портретная");
                } else  {
                    txtor.setText("Альбомная");
                }
            } });

        btncnt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                txtcnt.setText(String.valueOf( ++count));
            } });

        @Override
        protected void onSaveInstanceState(Bundle icicle) {
            super.onSaveInstanceState(icicle);
            icicle.putInt("count", count);
        }

        @Override
        protected void onResume() {
            super.onResume();
            TextView txtcnt = (TextView) findViewById(R.id.textCount);
            txtcnt.setText(String.valueOf( count));
        }

    }
}